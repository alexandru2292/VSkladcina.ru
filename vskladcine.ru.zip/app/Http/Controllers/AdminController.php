<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
class AdminController extends SiteController
{
    public function __construct(){

        $this->template = config('settings.theme').'.admin.index';
    }
    public function index(){
        $this->content = view(config('settings.theme').'.admin.contentIndex')->render();
        return $this->renderOutputAdmin();
    }
}
