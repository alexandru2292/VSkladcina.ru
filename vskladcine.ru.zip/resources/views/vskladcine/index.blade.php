@extends(config('settings.theme').'.layouts.site')
@section('header')
    {!! $header !!}
@endsection

@section('content')
    {!! $content !!}
@endsection


